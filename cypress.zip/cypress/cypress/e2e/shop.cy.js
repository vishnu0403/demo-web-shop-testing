describe('"MyShop" Ecommerce', () => {
    describe('Home Page Tests', () => {
      beforeEach(() => {
        cy.visit("https://demo.x-cart.com/")
    })
        it('should load the home page and display the correct title', () => {
          cy.visit('https://demo.x-cart.com/demo/home.php');
          cy.title().should('include', 'Your Company Name');
          cy.url().should('eq', 'https://demo.x-cart.com/demo/home.php')
          cy.get('.dialog').should('be.visible');
          cy.get('.menu-manufacturers > .title-bar > h2').scrollIntoView({ duration: 2000 });
          cy.screenshot()
        });
      });
    describe('template spec', () => {
      it('passes', () => {
        cy.visit('https://demo.x-cart.com/demo/home.php');
        cy.get('.line3 > .search > form > .text').type('Apple iPod touch 8 GB');
        cy.get('.line3 > .search > form > .search-button').click();
        cy.screenshot()
        cy.get('.first > .item-box > .image > .image-wrapper > a > img').click()
        cy.get('.main-button > .button-right > .button-left').click()
        cy.get('.view-cart').click()
        cy.screenshot()
        cy.get('.line3 > .search > form > .text').type('Acer Aspire ONE 10.1" Netbook');
        cy.get('.line3 > .search > form > .search-button').click();
        cy.get('.image-wrapper > a > img').click()
        cy.screenshot()
        cy.get('.main-button > .button-right > .button-left').click()
        cy.get('.view-cart').click()
        cy.screenshot()
        cy.get('.checkout-3-button > a').click()
        cy.get('#b_firstname').type('venky')
        cy.get('#b_lastname').type('reddy')
        cy.get('#b_address').type('1-23,srinivasa center')
        cy.get('#b_city').type('Nandyal')
        cy.get('#b_country').select('United States')
        cy.wait(3000)
        cy.screenshot()
        cy.get('#address_book_B_state').select('New York')
        cy.get('#b_zipcode').type('54367')
        cy.get('#b_phone').type('7894567834')
        cy.get('#email').type('venky@gmail.com')
        cy.get('.button-row > .button > .button-right > .button-left').click()
        cy.get('#pm7').click()
        cy.screenshot()
        cy.get('#accept_terms').click()
        cy.get('.button-left').click()
        cy.get('.text-block').should('contain','Congratulations! Your order has been successfully placed.')
        cy.screenshot()
         
      })
    })
    describe('login', () => { 
        beforeEach(() => { 
            cy.visit('https://demo.x-cart.com/'); 
        }); 
    it("login with valid username password",()=>{
        cy.visit("https://demo.x-cart.com/")
        cy.get('.header-links > #href_Sign_in').click()
        cy.get("#username").clear().type("abc123@gmail.com")
        cy.get("#password").clear().type("Abc12345")
        cy.get("button[title='Submit'] span[class='button-left']").click()
        cy.screenshot()
    })
    })
})